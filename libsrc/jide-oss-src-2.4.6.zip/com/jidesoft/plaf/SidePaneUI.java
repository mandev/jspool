/*
 * @(#)JideSidePaneUI.java
 *
 * Copyright 2002 JIDE Software Inc. All rights reserved.
 */
package com.jidesoft.plaf;

import javax.swing.plaf.PanelUI;

/**
 * ComponentUI for SidePane.
 */
public abstract class SidePaneUI extends PanelUI {
}
